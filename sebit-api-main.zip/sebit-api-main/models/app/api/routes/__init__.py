"""Route declarations for SEBIT Engine API."""

