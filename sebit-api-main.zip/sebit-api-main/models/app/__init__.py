"""SEBIT models FastAPI application package."""

from .main import create_app

__all__ = ["create_app"]
